/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messagingapp2;

/**
 *
 * @author Student
 */
public class MessagingApp2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
